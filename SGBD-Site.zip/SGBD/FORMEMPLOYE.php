<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Employés</title>
    <link rel="stylesheet" href="Form.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

</head>

<body class="mybody" style="background-image: url(Image.jpg) ;
  background-size: cover;
  background-position: center;
  background-size:1500px , 1500px;
    background-repeat: no-repeat;
    background-attachment: scroll;
    font-weight: bolder;">
    <div class="wrapper">
        <form id="addEmployeeForm" method="post" onsubmit="return validateForm()">
            <h1>Ajouter un Employé</h1>
            <div class="input-box">
                <label for="name">Nom :</label>
                <input type="text" maxlength="20" placeholder="Nom" id="name" name="name" class="form-control"
                    pattern="[A-Za-zÀ-ÿ\s]+" required>

            </div>
            <div class="input-box">
                <label for="prenom">Prénom :</label>
                <input type="text" maxlength="20" placeholder="Prénom" id="prenom" name="prenom" class="form-control"
                    pattern="[A-Za-zÀ-ÿ\s]+" required>
            </div>

            <div class="input-box">
                <label for="telephone">Téléphone :</label>
                <input type="text" maxlength="15" placeholder="Num" id="telephone" name="telephone" class="form-control"
                    pattern="\d+" required>

            </div>
            <button type="submit" class="btn btn-outline-success">Ajouter</button>
        </form>

        <h1>Liste des Employés</h1>
        <table class="table table-dark table-sm">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>Téléphone</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Afficher les erreurs pour le débogage
                ini_set('display_errors', 1);
                ini_set('display_startup_errors', 1);
                error_reporting(E_ALL);

                // Informations de connexion à la base de données Oracle
                $db_host = 'localhost';
                $db_port = '1521'; // Port par défaut pour Oracle
                $db_name = 'XE'; // Nom du service Oracle
                $db_user = 'IFRI'; // Utilisateur Oracle
                $db_pass = 'IFRI1'; // Mot de passe Oracle
                
                try {
                    // Connexion à la base de données Oracle avec PDO
                    $conn = new PDO("oci:dbname=//$db_host:$db_port/$db_name", $db_user, $db_pass);
                    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                    // Si le formulaire a été soumis
                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                        // Vérifier et sécuriser les données du formulaire
                        $name = !empty($_POST['name']) ? htmlspecialchars($_POST['name'], ENT_QUOTES, 'UTF-8') : null;
                        $prenom = !empty($_POST['prenom']) ? htmlspecialchars($_POST['prenom'], ENT_QUOTES, 'UTF-8') : null;
                        $telephone = !empty($_POST['telephone']) ? htmlspecialchars($_POST['telephone'], ENT_QUOTES, 'UTF-8') : null;

                        // Valider les données côté serveur
                        $errors = [];
                        if (!preg_match("/^[A-Za-zÀ-ÿ\s]+$/", $name)) {
                            $errors[] = "Le nom doit contenir uniquement des lettres.";
                        }
                        if (!preg_match("/^[A-Za-zÀ-ÿ\s]+$/", $prenom)) {
                            $errors[] = "Le prénom doit contenir uniquement des lettres.";
                        }
                        if (!preg_match("/^\d+$/", $telephone)) {
                            $errors[] = "Le téléphone doit contenir uniquement des chiffres.";
                        }

                        if (empty($errors)) {
                            // Préparer la requête SQL d'insertion
                            $sql = "INSERT INTO employe (NOM_EMP, PRENOM_EMP, NUM_TEL) VALUES (:nom, :prenom, :telephone)";
                            $stmt = $conn->prepare($sql);
                            $stmt->bindParam(':nom', $name);
                            $stmt->bindParam(':prenom', $prenom);
                            $stmt->bindParam(':telephone', $telephone);

                            // Exécuter la requête
                            $stmt->execute();

                            // Indiquer à JavaScript de réinitialiser le formulaire
                            echo "<script>
                                    document.getElementById('addEmployeeForm').reset();
                                  </script>";

                        } else {
                            foreach ($errors as $error) {
                                echo "<p class='text-danger'>$error</p>";
                            }
                        }
                    }

                    // Requête SQL pour sélectionner les données de la table
                    $sql = "SELECT ID_EMP, NOM_EMP, PRENOM_EMP, NUM_TEL FROM employe";
                    $stmt = $conn->query($sql);

                    // Récupérer et afficher les résultats
                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['ID_EMP'], ENT_QUOTES, 'UTF-8') . "</td>";
                        echo "<td>" . htmlspecialchars($row['NOM_EMP'], ENT_QUOTES, 'UTF-8') . "</td>";
                        echo "<td>" . htmlspecialchars($row['PRENOM_EMP'], ENT_QUOTES, 'UTF-8') . "</td>";
                        echo "<td>" . htmlspecialchars($row['NUM_TEL'], ENT_QUOTES, 'UTF-8') . "</td>";
                        echo "</tr>";
                    }

                } catch (PDOException $e) {
                    echo "Erreur : " . $e->getMessage();
                }
                
                ?>
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <script>
        function validateForm() {
            var name = document.getElementById("name").value;
            var prenom = document.getElementById("prenom").value;
            var telephone = document.getElementById("telephone").value;
            var namePattern = /^[A-Za-zÀ-ÿ\s]+$/;
            var phonePattern = /^\d+$/;

            if (!namePattern.test(name)) {
                alert("Le nom doit contenir uniquement des lettres.");
                return false;
            }
            if (!namePattern.test(prenom)) {
                alert("Le prénom doit contenir uniquement des lettres.");
                return false;
            }
            if (!phonePattern.test(telephone)) {
                alert("Le téléphone doit contenir uniquement des chiffres.");
                return false;
            }

            return true;
        }
    </script>
</body>

</html>