<?php
// Informations de connexion à la base de données Oracle
$db_host = 'localhost';
$db_port = '1521'; // Port par défaut pour Oracle
$db_name = 'XE'; // Nom du service Oracle
$db_user = 'IFRI'; // Utilisateur Oracle
$db_pass = 'IFRI1'; // Mot de passe Oracle

try {
    // Connexion à la base de données Oracle avec PDO
    $conn = new PDO("oci:dbname=//$db_host:$db_port/$db_name", $db_user, $db_pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Requête SQL pour sélectionner les données de la table
    $sql = "SELECT ID_EMP, NOM_EMP, PRENOM_EMP, NUM_TEL FROM employe";
    $stmt = $conn->query($sql);

    // Récupérer et afficher les résultats
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['ID_EMP']) . "</td>";
        echo "<td>" . htmlspecialchars($row['NOM_EMP']) . "</td>";
        echo "<td>" . htmlspecialchars($row['PRENOM_EMP']) . "</td>";
        echo "<td>" . htmlspecialchars($row['NUM_TEL']) . "</td>";
        echo "</tr>";
    }

} catch(PDOException $e) {
    echo "Erreur : " . $e->getMessage();
}
?>
